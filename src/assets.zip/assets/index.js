import appLogo from "./growth_logo.png";

const images = {
  appLogo,
};

export default images;
